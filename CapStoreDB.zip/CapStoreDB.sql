-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.22-log - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for capstore
CREATE DATABASE IF NOT EXISTS `capstore` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `capstore`;

-- Dumping structure for table capstore.bankaccount
CREATE TABLE IF NOT EXISTS `bankaccount` (
  `AccntNum` varchar(50) DEFAULT NULL,
  `Balance` double DEFAULT NULL,
  `Pin` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table capstore.capstoredata
CREATE TABLE IF NOT EXISTS `capstoredata` (
  `Revenue` double DEFAULT NULL,
  `NumOfCust` int(11) DEFAULT NULL,
  `NumOfMerchants` int(11) DEFAULT NULL,
  `NoOfProducts` int(11) DEFAULT NULL,
  `NoOfOrders` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table capstore.cart
CREATE TABLE IF NOT EXISTS `cart` (
  `CustId` varchar(50) DEFAULT NULL,
  `ProductId` varchar(50) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table capstore.coupons
CREATE TABLE IF NOT EXISTS `coupons` (
  `CouponCode` varchar(50) NOT NULL,
  `ExpiryDate` date NOT NULL,
  PRIMARY KEY (`CouponCode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table capstore.customers
CREATE TABLE IF NOT EXISTS `customers` (
  `CustId` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `ContactNum` int(11) NOT NULL,
  `HouseNum` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `State` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `BankAccntNum` varchar(50) NOT NULL,
  PRIMARY KEY (`CustId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table capstore.customertransactions
CREATE TABLE IF NOT EXISTS `customertransactions` (
  `CustId` varchar(50) DEFAULT NULL,
  `ProductId` varchar(50) DEFAULT NULL,
  `DatePurchased` date DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `OrderId` varchar(50) DEFAULT NULL,
  `ModeOfTransaction` varchar(50) DEFAULT NULL,
  `TransactionStatus` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table capstore.delivery
CREATE TABLE IF NOT EXISTS `delivery` (
  `ShipmentId` varchar(50) DEFAULT NULL,
  `OrderId` varchar(50) DEFAULT NULL,
  `AgentName` varchar(50) DEFAULT NULL,
  `Status` varchar(50) DEFAULT NULL,
  `DueDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table capstore.feedback
CREATE TABLE IF NOT EXISTS `feedback` (
  `CustId` varchar(50) DEFAULT NULL,
  `MerchantId` varchar(50) DEFAULT NULL,
  `ProductId` varchar(50) DEFAULT NULL,
  `ProductRating` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table capstore.merchant
CREATE TABLE IF NOT EXISTS `merchant` (
  `MerchantId` varchar(50) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `DateAdded` date NOT NULL,
  `HouseNum` varchar(50) NOT NULL,
  `City` varchar(50) NOT NULL,
  `State` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `MerchantRating` varchar(50) NOT NULL,
  PRIMARY KEY (`MerchantId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table capstore.merchanttransaction
CREATE TABLE IF NOT EXISTS `merchanttransaction` (
  `MerchantId` varchar(50) DEFAULT NULL,
  `ProductId` varchar(50) DEFAULT NULL,
  `Quantity` int(11) DEFAULT NULL,
  `DateProductAdded` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table capstore.products
CREATE TABLE IF NOT EXISTS `products` (
  `ProductId` varchar(50) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `MerchantId` varchar(50) DEFAULT NULL,
  `Quantity` varchar(50) DEFAULT NULL,
  `Price` double DEFAULT NULL,
  `DateAdded` date DEFAULT NULL,
  `Category` varchar(50) DEFAULT NULL,
  `Discount` int(11) DEFAULT NULL,
  `ImageSrc` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table capstore.wishlist
CREATE TABLE IF NOT EXISTS `wishlist` (
  `CustId` varchar(50) DEFAULT NULL,
  `ProductId` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
